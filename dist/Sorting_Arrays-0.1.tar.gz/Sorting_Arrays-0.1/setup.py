
from setuptools import setup

setup(name='Sorting_Arrays',
      version='0.1',
      description='All major sorting algorithms in one package!',
      packages=['Sorting_Arrays'],
      zip_safe=False)