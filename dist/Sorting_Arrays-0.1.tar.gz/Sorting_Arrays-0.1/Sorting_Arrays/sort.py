from SortingClass import Sorting

array = [2,7,9,1,9,0,3,4,5,6]

toSort = Sorting(array)
toSort.bubbleSort()
#toSort.disp(2,'bubble ')
toSort.selectionSort()

